import { Inter } from 'next/font/google'
import Link from 'next/link'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="z-10 max-w-5xl w-full items-center justify-center font-mono text-sm lg:flex">
        <h1 className="text-4xl font-bold mb-8 text-center">IO Game</h1>
        <p className="text-center mb-8">
          A multiplayer browser-based game where players compete in a shared environment.
        </p>
        <div className="flex justify-center">
          <Link 
            href="/game" 
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Play Now
          </Link>
        </div>
      </div>
    </main>
  )
}
