'use client'

import { useEffect } from 'react'
import Head from 'next/head'

export default function Game() {
  useEffect(() => {
    // Load the game from the public directory
    const script = document.createElement('script')
    script.src = '/bundle.js'
    script.async = true
    document.body.appendChild(script)

    // Create game container if it doesn't exist
    if (!document.getElementById('game-container')) {
      const gameContainer = document.createElement('div')
      gameContainer.id = 'game-container'
      document.body.appendChild(gameContainer)
      
      const gameMenu = document.createElement('div')
      gameMenu.id = 'game-menu'
      gameMenu.innerHTML = `
        <h1>IO Game</h1>
        <div id="play-menu">
          <input type="text" id="username-input" placeholder="Enter your username" maxlength="15">
          <button id="play-button">Play</button>
          <div id="game-message"></div>
        </div>
      `
      gameContainer.appendChild(gameMenu)
      
      const canvas = document.createElement('canvas')
      canvas.id = 'game-canvas'
      gameContainer.appendChild(canvas)
    }

    // Connect to the game server
    fetch('/api/game')
      .then(response => response.text())
      .then(data => console.log(data))
      .catch(error => console.error('Error connecting to game server:', error))

    return () => {
      // Clean up
      document.body.removeChild(script)
    }
  }, [])

  return (
    <>
      <Head>
        <title>IO Game</title>
        <meta name="description" content="A multiplayer browser-based IO game" />
      </Head>
      <div className="game-page">
        {/* The game will be loaded dynamically */}
      </div>
    </>
  )
}
