import { NextRequest } from 'next/server';

// Game state
let players = {};
let gameObjects = {};
let gameLoopInterval;
let powerUpInterval;
let leaderboardInterval;

// Constants
const CONSTANTS = {
  GAME_WIDTH: 1000,
  GAME_HEIGHT: 1000,
  PLAYER_RADIUS: 20,
  FOOD_RADIUS: 10,
  OBSTACLE_SIZE: 30
};

// API route handler
export async function GET(request: NextRequest) {
  return new Response('Game server is running. The game is available at /game', {
    status: 200,
    headers: {
      'Content-Type': 'text/plain',
    },
  });
}
