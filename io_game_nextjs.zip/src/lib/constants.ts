import { CONSTANTS } from '../../../io_game_project/src/shared/constants';

// Game constants
export const CONSTANTS = {
  GAME_WIDTH: 1000,
  GAME_HEIGHT: 1000,
  PLAYER_RADIUS: 20,
  FOOD_RADIUS: 10,
  OBSTACLE_SIZE: 30
};

// Export constants for use in other files
export default CONSTANTS;
